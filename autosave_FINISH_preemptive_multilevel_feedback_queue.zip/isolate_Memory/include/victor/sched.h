#ifndef __VICTOR_SCHED_H__
#define __VICTOR_SCHED_H__

//#include <proc.h>
#include <zjunix/pc.h>
void sched_init(void);
//void scheduler_schedule(void);
void scheduler_schedule(unsigned int status, unsigned int cause, context* pt_context);
//void wakeup_proc(struct proc_struct *proc);

//interface
void sched_class_enqueue(int procASID);


#endif /* !__VICTOR_SCHED_H__ */

/*

    sched_class_enqueue(idleproc);//enqueue
	pcb[idleproc].counter = PROC_DEFAULT_TIMESLOTS;     //Step 1. initilize all the PCBs

*/