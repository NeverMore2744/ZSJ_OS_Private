// ps2: display intermedia info
// #define PS2_DEBUG

// sd driver: display hardware-related info
// #define SD_DEBUG

// vga: calibrate vga output
// #define VGA_CALIBRATE

// memset
// #define MEMSET_DEBUG

// boot mem
// #define BOOTMM_DEBUG

// slab: display debug info
// #define SLAB_DEBUG

// myvi: display debug info
// #define MYVI_DEBUG

// file system
// #define FS_DEBUG

// exec
// #define EXEC_DEBUG