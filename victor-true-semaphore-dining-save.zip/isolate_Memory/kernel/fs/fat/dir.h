#ifndef _FAT_DIR_H
#define _FAT_DIR_H

#include <zjunix/fs/fat.h>

#endif  // ! _FAT_DIR_H