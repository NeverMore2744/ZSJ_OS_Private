#ifndef __KERN_SCHEDULE_SCHED_H__
#define __KERN_SCHEDULE_SCHED_H__

//#include <defs.h>

///
#define MLFQ_QUEUE_LEVEL 2
struct MLFQ_queue
{
	int items[MAX_PID];
	int head;//the first valid item, -1
	int tail;//the first place to write, 0
	int size;//MAX_PID
	
	// 将进程 p 插入队列 rq
	void (*enqueue)(struct MLFQ_queue *ptr_one_q, int procASID);
	//dequeue, return an int: procASID
	int (*dequeue)(struct MLFQ_queue *ptr_one_q);
};

//struct MLFQ_queue;
void MLFQ_queue_enque(struct MLFQ_queue *ptr_one_q, int procASID);
int MLFQ_queue_deque(struct MLFQ_queue *ptr_one_q );

//struct MLFQ_all_queues;
struct MLFQ_all_queues
{
	struct MLFQ_queue _queue[MLFQ_QUEUE_LEVEL];
	int queue_count;//MLFQ_QUEUE_LEVEL
};

void MLFQ_enqueue_first_time(struct MLFQ_all_queues *ptr_queues, int procASID);
void MLFQ_enqueue_second_time(struct MLFQ_all_queues *ptr_queues, int procASID); 
int MLFQ_dequeue(struct MLFQ_all_queues *ptr_queues);

//debug
static void print_queues();
#endif /* !__KERN_SCHEDULE_SCHED_H__ */

