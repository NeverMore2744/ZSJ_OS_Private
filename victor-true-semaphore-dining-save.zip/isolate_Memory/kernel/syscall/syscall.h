#ifndef __PRIVATE_SYSCALL_H__
#define __PRIVATE_SYSCALL_H__

void syscall(void);

#endif /* !__PRIVATE_SYSCALL_H__ */