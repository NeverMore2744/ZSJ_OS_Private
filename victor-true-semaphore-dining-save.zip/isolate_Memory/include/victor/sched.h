#ifndef __VICTOR_SCHED_H__
#define __VICTOR_SCHED_H__

//#include <proc.h>
#include <zjunix/pc.h>
#define PROC_DEFAULT_TIMESLOTS 1//2//time in the first level queue
#define PROC_SECOND_TIME_DEFAULT_TIMESLOTS 1//4//time in the second level queue

void sched_init(void);
//void scheduler_schedule(void);
void scheduler_schedule(unsigned int status, unsigned int cause, context* pt_context);

//dead function try to reschedule 
int pc_re_schedule_syscall(unsigned int status, unsigned int cause, context* pt_context);
//void wakeup_proc(struct proc_struct *proc);

//interface
void sched_class_enqueue(int procASID);


#endif /* !__VICTOR_SCHED_H__ */

/*

    sched_class_enqueue(idleproc);//enqueue
	pcb[idleproc].counter = PROC_DEFAULT_TIMESLOTS;     //Step 1. initilize all the PCBs

*/