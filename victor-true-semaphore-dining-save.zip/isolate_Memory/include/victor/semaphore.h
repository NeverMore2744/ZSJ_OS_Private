#ifndef __VICTOR_SYNC_SEM_H__
#define __VICTOR_SYNC_SEM_H__

//#include <defs.h>
#include <auxillary/defs.h>
#include <zjunix/pc.h>
//#include <atomic.h>
//#include <wait.h>

#define SEMAPHORE_MAX_NAME_LEN 32
typedef struct {
    int value;
    //wait_queue_t wait_queue;
	int wait_queue[MAX_PID];
	int head;//the next to read, read ptr
	int tail;//the next to write, write ptr
	char name[SEMAPHORE_MAX_NAME_LEN];
	
	//debug information
	bool private_is_initialized;
} semaphore;
/*
	value>0，表示共享资源的空闲数
	vlaue<0，表示该信号量的等待队列里的进程数
	value=0，表示等待队列为空
 */

void sem_init(semaphore *sem, int value, char* name);
void up(semaphore *sem);
void down(semaphore *sem);
//bool try_down(semaphore *sem);//!unimplemented
void sem_print_wait_queues(semaphore *sem);

#endif /* !__VICTOR_SYNC_SEM_H_ */