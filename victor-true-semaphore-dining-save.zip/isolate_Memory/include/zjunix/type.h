#ifndef _ZJUNIX_TYPE_H
#define _ZJUNIX_TYPE_H

typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;

#endif // ! _ZJUNIX_TYPE_H