////it seems that "ps" is the abbreviation of "Power shell". This file is mainly about the implementatin of shell.
#ifndef _PS_H
#define _PS_H
void ps();
void parse_cmd();
#endif
